export default function Home() {
    return <div>Home default  Page Content</div>;
  }