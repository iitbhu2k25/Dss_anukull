import GridSection from './component/home_grid/GridSection';
import GalleryCarousel from './component/project_images/GalleryCarousel';
export default function Home() {
    return(<div>
      <GridSection/>
      <GalleryCarousel/>
      main home page Page Content</div>);
  }
  