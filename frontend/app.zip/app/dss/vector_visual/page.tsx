'use client'
const vectorVisual = () => {
    return (
        <div>
            <h1 className="text-3xl font-bold underline">
                vector Visual
            </h1>
        </div>
    )
}
export default vectorVisual