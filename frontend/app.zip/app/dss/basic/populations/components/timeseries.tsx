
'use client'
import React from "react"

const TimeMethods = () => {
    return (
        <div className="p-4">
            <div className=" ">
            <div className="flex gap-14 flex-wrap">
                <span>1. Arithmetic Increase Method</span>
                <span>2. Geometric Increase Method</span>
                <span>3. Logistic Method</span>
                <span>4. Exponential Method</span>
                <span>5. Incremental Method</span>
            </div>
            </div>
        </div>
    )
}

export default TimeMethods