'use client'
import React,{useState} from "react"
const demographic_population=()=>{
    const [Annual_birth_rate, setAnnual_birth_rate] = useState(0);
    const [Annual_death_rate, setAnnual_death_rate] = useState(0);
    const [Annual_emigration_rate, setAnnual_emigration_rate] = useState(0);
    const [Annual_immigration_rate, setAnnual_immigration_rate] = useState(0);
    return(
        <div>
            anual
        </div>
    );
}
export default demographic_population