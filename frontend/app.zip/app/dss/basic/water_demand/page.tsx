"use client"
import React from "react"

const Water_Demand: React.FC = () => {
    return (
        <div>
            water demand
        </div>
    )
}


export default Water_Demand