"use client"
import React from "react"

const Water_Supply: React.FC = () => {
    return (
        <div>
            water supply
        </div>
    )
}


export default Water_Supply