"use client"
import React from "react"

const Sewage: React.FC = () => {
    return (
        <div>
            sewage
        </div>
    )
}


export default Sewage